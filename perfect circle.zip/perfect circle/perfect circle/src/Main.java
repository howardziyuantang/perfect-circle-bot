import java.awt.*;
import java.awt.event.InputEvent;

public class Main {

    public static void main(String[] args) throws AWTException {

        Robot robot = new Robot();
        robot.delay(3000);
        double dt = .03, r = 300, cx = 768, cy = 432;
//        robot.mouseMove((int)(cx+r),(int)cy);
        boolean first = true;
        for(double t = 0; t <= 2*Math.PI; t+=dt) {
//            int squigglyR = (int) (r+r/100d*Math.sin(20*t));
            robot.mouseMove((int)(cx+r*Math.cos(t)),(int)(cy+r*Math.sin(t)));
            if(first) {
                robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                first = false;
            }
        }
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//        System.out.println(MouseInfo.getPointerInfo().getLocation()); //768, 432 - center of white dot

    }

}
